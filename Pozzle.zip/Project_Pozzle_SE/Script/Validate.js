function printname(e){
    var test1
    var message
    var test2 = document.querySelector('#Test2')
    var Name= document.getElementById("name").value;
    var text = document.getElementById("outName").innerText = Name;
    var error = document.querySelector('#error')
    test1 = text
    if(test1 == "" || test1.length < 3){
        message = "*Name is invalid"
        error.textContent = message
    }
    else{
        sessionStorage.setItem("test1", test1)
        window.location.href = "difficult.html"
    }
}

function ClickPicture1(){
    var flag;
    flag = 1;
    var temp1;
    temp1 = flag;
    sessionStorage.setItem("temp1", temp1)
}

function ClickPicture2(){
    var flag;
    flag = 2;
    var temp1;
    temp1 = flag;
    sessionStorage.setItem("temp1", temp1)
}

function ClickPicture3(){
    var flag;
    flag = 3;
    var temp1;
    temp1 = flag;
    sessionStorage.setItem("temp1", temp1)
}



