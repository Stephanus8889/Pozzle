var hasil2 = sessionStorage.getItem("temp1")
var test3 = document.querySelector("#Test3")
var hasil = sessionStorage.getItem("test1");
var test2 = document.querySelector("#Test2");

if(hasil2 == 1){
    document.getElementById("img1").style.display = 'block';
    document.getElementById("img2").style.display = 'none';
    document.getElementById("img3").style.display = 'none';
}
else if(hasil2 == 2){
    document.getElementById("img1").style.display = 'none';
    document.getElementById("img2").style.display = 'block';
    document.getElementById("img3").style.display = 'none';
}
else if(hasil2 == 3){
    document.getElementById("img1").style.display = 'none';
    document.getElementById("img2").style.display = 'none';
    document.getElementById("img3").style.display = 'block';
}

test2.textContent = hasil