function start(time, display){
    var duration = time, minutes, seconds;
    setInterval(function(){
        minutes = parseInt(duration / 60, 10);
        seconds = parseInt(duration % 60, 10);

        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;
        
        display.textContent = minutes + ":" + seconds;

        if(--duration == 0){
            window.location.href = "GameOver.html";
        }
    }, 1000);
}

window.onload = function(){
    var time = 2 * 60,
    display = document.querySelector('#longtime');
    start(time, display);
}

